package com.vidula.careconnect;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PrescriptionManagerActivity extends AppCompatActivity {

    EditText editId, editMed, editDosage, editInstr;
    Button btnSave, btnClear, btnSearch, btnDelete;

    PrescriptionDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_manager); // adjust to your XML file name

        editId = findViewById(R.id.prescriptionId);
        editMed = findViewById(R.id.medicationName);
        editDosage = findViewById(R.id.dosage);
        editInstr = findViewById(R.id.instructions);
        btnSave = findViewById(R.id.savePrescriptionButton);
        btnClear = findViewById(R.id.clearPrescriptionButton2);

        // Optional buttons if added to XML
        btnSearch = findViewById(R.id.searchPrescriptionButton);
        btnDelete = findViewById(R.id.deletePrescriptionButton);

        dbHelper = new PrescriptionDBHelper(this);

        // CREATE / UPDATE
        btnSave.setOnClickListener(v -> {
            String id = editId.getText().toString();
            String med = editMed.getText().toString();
            String dosage = editDosage.getText().toString();
            String instr = editInstr.getText().toString();

            Cursor cursor = dbHelper.getPrescription(id);
            if (cursor.getCount() > 0) {
                boolean updated = dbHelper.updatePrescription(id, med, dosage, instr);
                Toast.makeText(this, updated ? "Prescription updated" : "Update failed", Toast.LENGTH_SHORT).show();
            } else {
                boolean inserted = dbHelper.insertPrescription(id, med, dosage, instr);
                Toast.makeText(this, inserted ? "Prescription saved" : "Save failed", Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        });

        // CLEAR
        btnClear.setOnClickListener(v -> {
            editId.setText("");
            editMed.setText("");
            editDosage.setText("");
            editInstr.setText("");
        });

        // READ
        btnSearch.setOnClickListener(v -> {
            String id = editId.getText().toString();
            Cursor cursor = dbHelper.getPrescription(id);
            if (cursor.moveToFirst()) {
                editMed.setText(cursor.getString(cursor.getColumnIndexOrThrow("medication")));
                editDosage.setText(cursor.getString(cursor.getColumnIndexOrThrow("dosage")));
                editInstr.setText(cursor.getString(cursor.getColumnIndexOrThrow("instructions")));
                Toast.makeText(this, "Prescription found", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No prescription found", Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        });

        // DELETE
        btnDelete.setOnClickListener(v -> {
            String id = editId.getText().toString();
            boolean deleted = dbHelper.deletePrescription(id);
            Toast.makeText(this, deleted ? "Prescription deleted" : "Delete failed", Toast.LENGTH_SHORT).show();
        });
    }
}
