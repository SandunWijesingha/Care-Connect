package com.vidula.careconnect;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class DoctorActivity extends AppCompatActivity {

    EditText nameInput, ageInput, locationInput, contactInput, emailInput;
    Button findDoctorButton;
    TextView successMessage;
    RecyclerView doctorRecyclerView;

    ArrayList<DoctorModel> doctorList;
    DoctorAdapter doctorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);

        nameInput = findViewById(R.id.patient_name_input);
        ageInput = findViewById(R.id.age_input);
        locationInput = findViewById(R.id.location_input);
        contactInput = findViewById(R.id.contact_input);
        emailInput = findViewById(R.id.email_input);
        findDoctorButton = findViewById(R.id.find_hospital_button);
        successMessage = findViewById(R.id.success_message);
        doctorRecyclerView = findViewById(R.id.doctor_recycler_view);

        doctorList = new ArrayList<>();
        doctorAdapter = new DoctorAdapter(doctorList);
        doctorRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        doctorRecyclerView.setAdapter(doctorAdapter);

        findDoctorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameInput.getText().toString().trim();
                String age = ageInput.getText().toString().trim();
                String location = locationInput.getText().toString().trim();
                String contact = contactInput.getText().toString().trim();
                String email = emailInput.getText().toString().trim();

                if (name.isEmpty() || age.isEmpty() || location.isEmpty() ||
                        contact.isEmpty() || email.isEmpty()) {
                    Toast.makeText(DoctorActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                doctorList.add(new DoctorModel(name, age, location, contact, email));
                doctorAdapter.notifyItemInserted(doctorList.size() - 1);

                successMessage.setVisibility(View.VISIBLE);
                clearInputs();
            }
        });
    }

    private void clearInputs() {
        nameInput.setText("");
        ageInput.setText("");
        locationInput.setText("");
        contactInput.setText("");
        emailInput.setText("");
    }

    // Inner class: Model
    class DoctorModel {
        String name, age, location, contact, email;

        public DoctorModel(String name, String age, String location, String contact, String email) {
            this.name = name;
            this.age = age;
            this.location = location;
            this.contact = contact;
            this.email = email;
        }
    }

    // Inner class: Adapter
    class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {
        ArrayList<DoctorModel> list;

        public DoctorAdapter(ArrayList<DoctorModel> list) {
            this.list = list;
        }

        @Override
        public DoctorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new DoctorViewHolder(view);
        }

        @Override
        public void onBindViewHolder(DoctorViewHolder holder, int position) {
            DoctorModel model = list.get(position);
            holder.line1.setText(model.name + " (" + model.age + ")");
            holder.line2.setText("Location: " + model.location + " | Contact: " + model.contact + " | Email: " + model.email);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class DoctorViewHolder extends RecyclerView.ViewHolder {
            TextView line1, line2;

            public DoctorViewHolder(View itemView) {
                super(itemView);
                line1 = itemView.findViewById(android.R.id.text1);
                line2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}
