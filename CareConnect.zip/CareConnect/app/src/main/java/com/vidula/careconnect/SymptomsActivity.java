package com.vidula.careconnect;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SymptomsActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText etPatientName, etSymptoms;
    Button btnAdd, btnUpdate, btnDelete;
    ListView listView;
    ArrayAdapter<String> adapter;
    ArrayList<String> dataList;
    String selectedId = "";
    TextView tvDiagnosis; // Declaration moved here for proper initialization

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);

        myDb = new DatabaseHelper(this);

        etPatientName = findViewById(R.id.etPatientName);
        etSymptoms = findViewById(R.id.etSymptoms);
        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        listView = findViewById(R.id.listViewPatients);
        tvDiagnosis = findViewById(R.id.tvDiagnosis); // Initialize TextView here

        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        listView.setAdapter(adapter);

        loadData();

        // Add Patient and Symptoms
        btnAdd.setOnClickListener(v -> {
            String name = etPatientName.getText().toString();
            String symptoms = etSymptoms.getText().toString();
            if (myDb.insertData(name, symptoms)) {
                Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
                loadData();
            }
        });

        // Update Patient and Symptoms
        btnUpdate.setOnClickListener(v -> {
            if (!selectedId.equals("")) {
                String name = etPatientName.getText().toString();
                String symptoms = etSymptoms.getText().toString();
                if (myDb.updateData(selectedId, name, symptoms)) {
                    Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                    loadData();
                }
            }
        });

        // Delete Patient Record
        btnDelete.setOnClickListener(v -> {
            if (!selectedId.equals("")) {
                myDb.deleteData(selectedId);
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                loadData();
            }
        });

        // ListView Item Click
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String item = dataList.get(position);
            String[] parts = item.split(":");
            selectedId = parts[0];
            Cursor cursor = myDb.getAllData();
            while (cursor.moveToNext()) {
                if (cursor.getString(0).equals(selectedId)) {
                    etPatientName.setText(cursor.getString(1));
                    etSymptoms.setText(cursor.getString(2));
                }
            }
        });

        // TextWatcher for Symptoms input
        etSymptoms.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String suggestion = suggestDiagnosis(s.toString());
                tvDiagnosis.setText("Diagnosis Suggestion: " + suggestion);  // Display suggestion
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }

    // Function to suggest diagnosis based on symptoms
    private String suggestDiagnosis(String symptoms) {
        symptoms = symptoms.toLowerCase();

        if (symptoms.contains("fever") && symptoms.contains("cough")) {
            return "Possible: Flu or COVID-19";
        } else if (symptoms.contains("headache") && symptoms.contains("nausea")) {
            return "Possible: Migraine";
        } else if (symptoms.contains("fever") && symptoms.contains("rash")) {
            return "Possible: Dengue or Measles";
        } else if (symptoms.contains("chest pain")) {
            return "Possible: Heart-related issue";
        } else if (symptoms.contains("sore throat")) {
            return "Possible: Throat infection";
        } else if (symptoms.contains("diarrhea")) {
            return "Possible: Food poisoning or stomach flu";
        } else {
            return "No clear suggestion. Consult a doctor.";
        }
    }

    // Load patient data into ListView
    private void loadData() {
        Cursor res = myDb.getAllData();
        if (res.getCount() == 0) {
            Toast.makeText(this, "No records found", Toast.LENGTH_SHORT).show();
            return;
        }

        dataList.clear();
        while (res.moveToNext()) {
            dataList.add(res.getString(0) + ": " + res.getString(1) + " - " + res.getString(2));
        }
        adapter.notifyDataSetChanged();
        etPatientName.setText("");
        etSymptoms.setText("");
        selectedId = "";
    }
}
