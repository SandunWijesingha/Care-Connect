package com.vidula.careconnect;

import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class HealthTipsActivity extends AppCompatActivity {

    EditText etKeyword;
    Button btnGetTip;
    TextView tvTipResult;
    VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_tips);

        etKeyword = findViewById(R.id.etKeyword);
        btnGetTip = findViewById(R.id.btnGetTip);
        tvTipResult = findViewById(R.id.tvTipResult);
        videoView = findViewById(R.id.videoView);

        // Play sample video (optional)
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.medicalanimation01;
        videoView.setVideoURI(Uri.parse(videoPath));
        videoView.start();

        btnGetTip.setOnClickListener(v -> {
            String keyword = etKeyword.getText().toString().trim().toLowerCase();
            String tip = getHealthTip(keyword);
            tvTipResult.setText(tip);
        });
    }

    private String getHealthTip(String keyword) {
        switch (keyword) {
            case "cold":
            case "cough":
                return "Stay hydrated and rest. Try ginger tea or warm lemon water.";
            case "stress":
                return "Practice deep breathing, yoga, or a short walk to relax.";
            case "diet":
                return "Include fruits, vegetables, and plenty of water in your meals.";
            case "fitness":
            case "exercise":
                return "30 minutes of daily activity boosts energy and mental health.";
            case "sleep":
                return "Avoid screens before bed. Aim for 7–8 hours of sleep nightly.";
            case "hydration":
            case "water":
                return "Drink at least 8 glasses of water per day to stay refreshed.";
            case "eye":
                return "Take breaks from screens every 20 minutes to rest your eyes.";
            default:
                return "Try keywords like cold, stress, diet, sleep, hydration, etc.";
        }
    }
}
