package com.vidula.careconnect;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PrescriptionDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Prescriptions.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "prescriptions";
    public static final String COL_ID = "id";
    public static final String COL_MEDICATION = "medication";
    public static final String COL_DOSAGE = "dosage";
    public static final String COL_INSTRUCTIONS = "instructions";

    public PrescriptionDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " TEXT PRIMARY KEY, " +
                COL_MEDICATION + " TEXT, " +
                COL_DOSAGE + " TEXT, " +
                COL_INSTRUCTIONS + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Create
    public boolean insertPrescription(String id, String med, String dosage, String instr) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ID, id);
        values.put(COL_MEDICATION, med);
        values.put(COL_DOSAGE, dosage);
        values.put(COL_INSTRUCTIONS, instr);
        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    // Read
    public Cursor getPrescription(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_ID + "=?", new String[]{id});
    }

    // Update
    public boolean updatePrescription(String id, String med, String dosage, String instr) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_MEDICATION, med);
        values.put(COL_DOSAGE, dosage);
        values.put(COL_INSTRUCTIONS, instr);
        int rows = db.update(TABLE_NAME, values, COL_ID + "=?", new String[]{id});
        return rows > 0;
    }

    // Delete
    public boolean deletePrescription(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, COL_ID + "=?", new String[]{id});
        return rows > 0;
    }
}
